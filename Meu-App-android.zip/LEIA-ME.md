# Meu App

Gerar o APK:

**Opção A – GitHub (sem instalar nada):** crie um repositório, envie estes arquivos e abra a aba *Actions*. Ao terminar, baixe o artefato "app-debug-apk".

**Opção B – Android Studio:** abra esta pasta e clique em *Build > Build APK(s)*.
